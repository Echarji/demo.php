<?php

/**
 * Used to store website configuration information.
 *
 * @var string
 */
function config($key = '')
{
    $config = [
        'name' => 'Demo PHP Website',
        'nav_menu' => [
            '' => 'Home',
            'about-us' => 'About Us',
            'products' => 'Products',
            'contact' => 'Contact',
        ],
        'template_path' => 'template',
        'content_path' => 'content',
        'pretty_uri' => true,
        'version' => 'v3.0',
        'nginx_version' => 'nginx/1.23.2',
        'php_version' => '8.1',
        'php_modules' => ['pdo', 'pdo_mysql', 'gd'],
        'mariadb_version' => '10.9.4',
        'db_user' => 'php_user',
        'db_password' => 'Nq4rnFpp2ihrmw8PRV7yo4H4',
    ];

    return isset($config[$key]) ? $config[$key] : null;
}
